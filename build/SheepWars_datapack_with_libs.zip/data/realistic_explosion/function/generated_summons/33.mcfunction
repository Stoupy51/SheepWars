
#> realistic_explosion:generated_summons/33
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:black_glazed_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:black_glazed_terracotta"}
execute if data storage realistic_explosion:main {id:"minecraft:blue_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:blue_stained_glass_pane"}
execute if data storage realistic_explosion:main {id:"minecraft:brown_glazed_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:brown_glazed_terracotta"}
execute if data storage realistic_explosion:main {id:"minecraft:calibrated_sculk_sensor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:calibrated_sculk_sensor"}
execute if data storage realistic_explosion:main {id:"minecraft:cracked_deepslate_tiles"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:cracked_deepslate_tiles"}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:cyan_stained_glass_pane"}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_pressure_plate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:dark_oak_pressure_plate"}
execute if data storage realistic_explosion:main {id:"minecraft:dead_bubble_coral_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:dead_bubble_coral_block"}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_chiseled_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:exposed_chiseled_copper"}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_copper_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:exposed_copper_trapdoor"}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_cut_copper_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:exposed_cut_copper_slab"}
execute if data storage realistic_explosion:main {id:"minecraft:flowering_azalea_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:flowering_azalea_leaves"}
execute if data storage realistic_explosion:main {id:"minecraft:gray_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:gray_stained_glass_pane"}
execute if data storage realistic_explosion:main {id:"minecraft:green_glazed_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:green_glazed_terracotta"}
execute if data storage realistic_explosion:main {id:"minecraft:lime_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:lime_stained_glass_pane"}
execute if data storage realistic_explosion:main {id:"minecraft:magenta_concrete_powder"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:magenta_concrete_powder"}
execute if data storage realistic_explosion:main {id:"minecraft:magenta_concrete_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:magenta_concrete_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_pressure_plate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:mangrove_pressure_plate"}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_copper_lantern"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:oxidized_copper_lantern"}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_pressure_plate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:pale_oak_pressure_plate"}
execute if data storage realistic_explosion:main {id:"minecraft:pink_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:pink_stained_glass_pane"}
execute if data storage realistic_explosion:main {id:"minecraft:polished_deepslate_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:polished_deepslate_slab"}
execute if data storage realistic_explosion:main {id:"minecraft:polished_deepslate_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:polished_deepslate_wall"}
execute if data storage realistic_explosion:main {id:"minecraft:polished_diorite_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:polished_diorite_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:polished_granite_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:polished_granite_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:prismarine_brick_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:prismarine_brick_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:red_nether_brick_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:red_nether_brick_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:repeating_command_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:repeating_command_block"}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_sandstone_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:smooth_sandstone_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_crimson_hyphae"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:stripped_crimson_hyphae"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_cut_copper_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_cut_copper_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:weathered_lightning_rod"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:weathered_lightning_rod"}
execute if data storage realistic_explosion:main {id:"minecraft:white_glazed_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:white_glazed_terracotta"}

