
#> realistic_explosion:generated_summons/40
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:infested_chiseled_stone_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:infested_chiseled_stone_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_blackstone_brick_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_blackstone_brick_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_blackstone_brick_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_blackstone_brick_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_chiseled_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_oxidized_chiseled_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_copper_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_oxidized_copper_trapdoor"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_cut_copper_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_oxidized_cut_copper_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_weathered_copper_lantern"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_weathered_copper_lantern"}}

