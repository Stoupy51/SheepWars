execute if data storage realistic_explosion:main {id:"minecraft:acacia_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:acacia_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:acacia_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:acacia_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:acacia_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:azure_bluet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:azure_bluet"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:birch_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:birch_fence"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_orchid"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_orchid"}}
execute if data storage realistic_explosion:main {id:"minecraft:brain_coral"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brain_coral"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cherry_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:coarse_dirt"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:coarse_dirt"}}
execute if data storage realistic_explosion:main {id:"minecraft:cobblestone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cobblestone"}}
execute if data storage realistic_explosion:main {id:"minecraft:copper_bulb"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:copper_bulb"}}
execute if data storage realistic_explosion:main {id:"minecraft:copper_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:copper_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cyan_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cyan_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cyan_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:diamond_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:diamond_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:dragon_head"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dragon_head"}}
execute if data storage realistic_explosion:main {id:"minecraft:emerald_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:emerald_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:ender_chest"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:ender_chest"}}
execute if data storage realistic_explosion:main {id:"minecraft:glow_lichen"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:glow_lichen"}}
execute if data storage realistic_explosion:main {id:"minecraft:grass_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:grass_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:gray_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gray_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:gray_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gray_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:gray_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gray_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:honey_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:honey_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:jungle_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:lapis_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lapis_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:lime_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lime_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:lime_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lime_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:lime_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lime_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:magenta_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:magenta_bed"}}
execute if data storage realistic_explosion:main {id:"minecraft:magma_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:magma_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:moss_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:moss_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:nether_wart"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:nether_wart"}}
execute if data storage realistic_explosion:main {id:"minecraft:oak_sapling"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oak_sapling"}}
execute if data storage realistic_explosion:main {id:"minecraft:orange_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:orange_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:oxeye_daisy"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oxeye_daisy"}}
execute if data storage realistic_explosion:main {id:"minecraft:piglin_head"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:piglin_head"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_banner"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_candle"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_carpet"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_petals"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_petals"}}
execute if data storage realistic_explosion:main {id:"minecraft:player_head"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:player_head"}}
execute if data storage realistic_explosion:main {id:"minecraft:purple_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purple_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:purpur_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purpur_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:quartz_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:quartz_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:rooted_dirt"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:rooted_dirt"}}
execute if data storage realistic_explosion:main {id:"minecraft:scaffolding"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:scaffolding"}}
execute if data storage realistic_explosion:main {id:"minecraft:sea_lantern"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:sea_lantern"}}
execute if data storage realistic_explosion:main {id:"minecraft:short_grass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:short_grass"}}
execute if data storage realistic_explosion:main {id:"minecraft:shroomlight"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:shroomlight"}}
execute if data storage realistic_explosion:main {id:"minecraft:shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:slime_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:slime_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:sniffer_egg"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:sniffer_egg"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:spruce_wood"}}
execute if data storage realistic_explosion:main {id:"minecraft:stonecutter"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stonecutter"}}
execute if data storage realistic_explosion:main {id:"minecraft:torchflower"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:torchflower"}}
execute if data storage realistic_explosion:main {id:"minecraft:tuff_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:tuff_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:tuff_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:tuff_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:warped_stem"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:warped_stem"}}
execute if data storage realistic_explosion:main {id:"minecraft:white_tulip"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:white_tulip"}}
execute if data storage realistic_explosion:main {id:"minecraft:wither_rose"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:wither_rose"}}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:yellow_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:zombie_head"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:zombie_head"}}
