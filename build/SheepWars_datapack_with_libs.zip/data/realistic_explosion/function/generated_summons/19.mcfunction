execute if data storage realistic_explosion:main {id:"minecraft:birch_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:birch_log"}}
execute if data storage realistic_explosion:main {id:"minecraft:black_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:black_bed"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:bookshelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bookshelf"}}
execute if data storage realistic_explosion:main {id:"minecraft:brown_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:brown_bed"}}
execute if data storage realistic_explosion:main {id:"minecraft:composter"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:composter"}}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cyan_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:dandelion"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dandelion"}}
execute if data storage realistic_explosion:main {id:"minecraft:dead_bush"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dead_bush"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate"}}
execute if data storage realistic_explosion:main {id:"minecraft:dirt_path"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dirt_path"}}
execute if data storage realistic_explosion:main {id:"minecraft:dispenser"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:dispenser"}}
execute if data storage realistic_explosion:main {id:"minecraft:end_stone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:end_stone"}}
execute if data storage realistic_explosion:main {id:"minecraft:frogspawn"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:frogspawn"}}
execute if data storage realistic_explosion:main {id:"minecraft:glowstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:glowstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:gray_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gray_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:green_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:green_bed"}}
execute if data storage realistic_explosion:main {id:"minecraft:hay_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:hay_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:iron_bars"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:iron_bars"}}
execute if data storage realistic_explosion:main {id:"minecraft:iron_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:iron_door"}}
execute if data storage realistic_explosion:main {id:"minecraft:lapis_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lapis_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:lime_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lime_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:lodestone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lodestone"}}
execute if data storage realistic_explosion:main {id:"minecraft:oak_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oak_fence"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_wool"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_tulip"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_tulip"}}
execute if data storage realistic_explosion:main {id:"minecraft:rose_bush"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:rose_bush"}}
execute if data storage realistic_explosion:main {id:"minecraft:sandstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:sandstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:soul_sand"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:soul_sand"}}
execute if data storage realistic_explosion:main {id:"minecraft:soul_soil"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:soul_soil"}}
execute if data storage realistic_explosion:main {id:"minecraft:sunflower"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:sunflower"}}
execute if data storage realistic_explosion:main {id:"minecraft:tuff_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:tuff_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:tuff_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:tuff_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:white_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:white_bed"}}
