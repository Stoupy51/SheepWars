
#> realistic_explosion:generated_summons/28
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:bamboo_mosaic_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bamboo_mosaic_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:birch_hanging_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:birch_hanging_sign"}}
execute if data storage realistic_explosion:main {id:"minecraft:blue_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:blue_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:bubble_coral_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:bubble_coral_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:chiseled_bookshelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chiseled_bookshelf"}}
execute if data storage realistic_explosion:main {id:"minecraft:chiseled_deepslate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chiseled_deepslate"}}
execute if data storage realistic_explosion:main {id:"minecraft:chiseled_sandstone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:chiseled_sandstone"}}
execute if data storage realistic_explosion:main {id:"minecraft:cobblestone_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cobblestone_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_fence_gate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:crimson_fence_gate"}}
execute if data storage realistic_explosion:main {id:"minecraft:cut_sandstone_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cut_sandstone_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:cyan_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_coal_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_coal_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_gold_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_gold_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:deepslate_iron_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:deepslate_iron_ore"}}
execute if data storage realistic_explosion:main {id:"minecraft:exposed_cut_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:exposed_cut_copper"}}
execute if data storage realistic_explosion:main {id:"minecraft:gray_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:gray_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:infested_deepslate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:infested_deepslate"}}
execute if data storage realistic_explosion:main {id:"minecraft:large_amethyst_bud"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:large_amethyst_bud"}}
execute if data storage realistic_explosion:main {id:"minecraft:lily_of_the_valley"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lily_of_the_valley"}}
execute if data storage realistic_explosion:main {id:"minecraft:lime_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:lime_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:magenta_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:magenta_terracotta"}}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_propagule"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mangrove_propagule"}}
execute if data storage realistic_explosion:main {id:"minecraft:mossy_stone_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:mossy_stone_bricks"}}
execute if data storage realistic_explosion:main {id:"minecraft:nether_brick_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:nether_brick_fence"}}
execute if data storage realistic_explosion:main {id:"minecraft:oak_pressure_plate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:oak_pressure_plate"}}
execute if data storage realistic_explosion:main {id:"minecraft:orange_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:orange_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:petrified_oak_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:petrified_oak_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:pink_stained_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:pink_stained_glass"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_deepslate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_deepslate"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_tuff_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_tuff_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:polished_tuff_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:polished_tuff_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:purple_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:purple_shulker_box"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_mushroom_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_mushroom_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_sandstone_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_sandstone_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:red_sandstone_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:red_sandstone_wall"}}
execute if data storage realistic_explosion:main {id:"minecraft:resin_brick_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:resin_brick_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:small_amethyst_bud"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:small_amethyst_bud"}}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_quartz_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:smooth_quartz_slab"}}
execute if data storage realistic_explosion:main {id:"minecraft:stone_brick_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stone_brick_stairs"}}
execute if data storage realistic_explosion:main {id:"minecraft:stripped_birch_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:stripped_birch_log"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_copper_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_copper_block"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_copper_chain"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_copper_chain"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_copper_chest"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_copper_chest"}}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_copper_grate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:waxed_copper_grate"}}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_shulker_box"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:{Name:"minecraft:yellow_shulker_box"}}

