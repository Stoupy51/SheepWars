
#> sheepwars:utils/new_sheep
#
# @executed	as @e[type=sheep,tag=sheepwars.new]
#
# @within	sheepwars:sheeps/final/fragmentation [ as @e[type=sheep,tag=sheepwars.new] ]
#			sheepwars:sheeps/summon/soutien [ as @e[tag=sheepwars.new] & at @s ]
#			sheepwars:utils/launch_entity_in_direction
#
# @input storage	sheepwars:main Rotation : 2D rotation of the entity
# @input storage	sheepwars:main UUID : UUID of the player who launched the entity
# 
# @description		Remove "new" tag and store launcher's UUID.
#

# Remove "new" tag
tag @s remove sheepwars.new

# Apply rotation to the entity
data modify entity @s Rotation set from storage sheepwars:main Rotation

# Store the launcher's UUID
data merge entity @s {equipment:{feet:{id:"minecraft:stone",count:1}},drop_chances:{feet:0.0f}}
data modify entity @s equipment.feet.components."minecraft:custom_data".UUID set from storage sheepwars:main UUID

# Join the sheepwars.sheeps team (no collisions)
team join sheepwars.sheeps

# Give fire resistance
effect give @s fire_resistance infinite 0 true

# Remove fall damage
attribute @s safe_fall_distance base set 1024

