
#> sheepwars:v2.5.1/load/secondary
#
# @within	sheepwars:v2.5.1/load/main
#

# SheepWars
scoreboard objectives add sheepwars.data dummy
tag Stoupy51 add convention.debug

# Check dependencies and wait for a player to connect (to get server version)
function sheepwars:v2.5.1/load/check_dependencies
function sheepwars:v2.5.1/load/valid_dependencies

